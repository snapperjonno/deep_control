// File: play_module.h
#pragma once

namespace play_module {
  void begin();
  void update();
};