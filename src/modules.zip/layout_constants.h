// File: layout_constants.h

#pragma once

// Shared across all screens
#define SCREEN_W      240
#define SCREEN_H      135

#define TRI_SIDE       20
#define TRI_MARGIN_L    7
#define TRI_MARGIN_R    7
