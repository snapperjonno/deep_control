// File: mode_manager.h
#pragma once

namespace mode_manager {
  void begin();
  void update();
  bool inSetupMode();
};